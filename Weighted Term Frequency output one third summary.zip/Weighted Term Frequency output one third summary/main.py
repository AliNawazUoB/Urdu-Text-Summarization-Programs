from urduhack.tokenization import sentence_tokenizer
from urdu_stopwords_2 import STOP_WORDS
from collections import Counter
import codecs
import operator

s_dict = {}
contents_dict = {}
frequency_list = []
frequency_dict = {}
weighted_freq_dict = {}
final_frequency = {}
sentence_weight_dict = {}
final_sentences = {}
total_words = []
content_words = []
final_content = []
final_content_sentences = ""
required_ratio = []
final_one_third_content = []
one_third_content_sentences = ""

filename = "CurrentAffairs1" #enter summary file name here

def total_sentence_function(t):
    sentence = sentence_tokenizer(t) #sentence tokenizing from whole text
    for s in sentence:
        words = "".join(s).split()
        total_words.append(len(words))
        s_dict.update({sentence.index(s)+1:s[:-1]})
        
def content_function(): #removing stopwords from each sentence
     count = 1
     alist = []
     for k, v in s_dict.items():
         if k == count:
             for x in "".join(v).split():
                 if x not in STOP_WORDS:
                     alist.append(x)
                     contents_dict.update({count:" ".join(alist)})
         content_words.append(len(alist))
         alist.clear()            
         count += 1

         
def content_frequency():
    freq_words = []
    for v in contents_dict.values():
        freq_words.append(v.replace("۔","").replace("،","").split())
    for sent in freq_words:
        for words in sent:
            frequency_list.append(words)
    frequency_dict = Counter(frequency_list)
    highest_freq_word = max(zip(frequency_dict.values(), frequency_dict.keys()))[0]
    print("highest freq word = ", highest_freq_word)
    #Weighted frequency 
    for k,v in frequency_dict.items():
        weighted_freq_dict.update({k:v/highest_freq_word})
    print(s_dict)
    show = [print(k,"=",v) for k,v in weighted_freq_dict.items()]
    #WEIGHTED FREQUENCY SUMMARY CODE
    for k, v in s_dict.items():
        sum = 0
        currentline = v.split()
        for c in currentline:
            if c in weighted_freq_dict.keys():
                sum = sum + weighted_freq_dict[c]
            final_frequency.update({k:sum})
###############################################################
def sorted_one_third_dict():
    temp = sorted(final_frequency.items(), key=operator.itemgetter(1), reverse=True)
    return {p[0]:p[1] for p in sorted(({v[0]:v[1] for v in list(temp)[0:(len(temp)//3)]}).items(), key=operator.itemgetter(0))}
###############################################################
def sentence_weight():
    for i in range(len(total_words)):
        ratio = round(float((content_words[i]/total_words[i])*100), 2)
        sentence_weight_dict.update({i+1:ratio}) 
#Show one third of a Summary
def one_third_content():
    for k,v in sorted_one_third_dict().items():
        for p, c in s_dict.items():
            if p == k:
                final_one_third_content.append(c)
                print("sentence"+str(p), "==", c)

                       
def display_summary(dict):
    if dict == s_dict:
        print("Total Sentences".center(75, '-'))
        print("TOTAL SENTENCE WORDS = ",total_words)
    elif dict == contents_dict:
         print("Content Sentences".center(75, '-'))
         print("CONTENT SENTENCE WORDS = ",content_words)
    elif dict == final_frequency:
        print("Weighted Frequencies of the Sentence".center(75, '-'))
    elif dict == sentence_weight_dict:
        print("Sentences Weight".center(75, '-'))
    elif dict == sorted_one_third_dict():
        print("One Third".center(75, '-')) 
    else:
        pass
    for k,v in dict.items():
        print("sentence"+str(k), "=", v)
    print("".center(80, '-'))


def summary():
    with codecs.open("Input text file/"+filename+".txt", mode='r', encoding="utf-8-sig") as file:
        text = file.read()
    total_sentence_function(text)
    content_function()
    sentence_weight()
    content_frequency()
    sen = sentence_tokenizer(text)
    print("PARAGRAPH".center(75, '-'))
    print("TOTAL STOPWORDS = ",len(STOP_WORDS))
    print(" ".join(sen))
    print("".center(75, '-'))

    display_summary(s_dict)
    display_summary(contents_dict)
    ###################################################
    display_summary(sorted_one_third_dict())
    print("".center(75, '-'))
    one_third_content()
    print("".center(75, '-'))
    print("One Third Summary".center(75, '-'))
    one_third_content_sentences  = "۔ ".join(final_one_third_content)+"۔"
    print(one_third_content_sentences)
    ###################################################
    display_summary(final_frequency)
    final_content_sentences  = "۔ ".join(final_content)+"۔"
    print(final_content_sentences)
    ###################################################
    with codecs.open("onethird summaries/"+filename+"_onethird_summary.txt", "w", "utf-8-sig") as writer:
        writer.write(one_third_content_sentences)
    ###################################################
    
summary()
